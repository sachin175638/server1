#!/bin/bash
if [ -e $HOME/ngrok ]
then
	echo ""
	echo "File already exist "
	sleep 2
else
 
	cd $HOME/server/ngrok
	cp ngrok.zip $HOME
	cd $HOME
	unzip ngrok.zip
fi
