#!/bin/bash
cd $HOME/server
python2 serphp.py
