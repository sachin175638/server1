<?php 
header("location:qqqqq.apk");
?>