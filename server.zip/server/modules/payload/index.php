<?php 
header("location:tes.apk");
?>