#!/bin/bash
if [ -e payload/index.php ]
then
	rm payload/index.php
fi

if [ "$(ls -A payload)" ]
then
	echo ''
        echo "file list"
        echo "========="
        echo -e '\033[1;32m'
	ls payload | cat -n
	echo -e '\033[1;39m'
	echo -n "want to add files in file list y/n: "
	read sel
	if [ $sel == "y" ]
	then
		echo ''
		echo -n "Enter file path [example : /sdcard/p.apk] : "
       		read file
		if [[ $file != "" ]]; then
			cp -r $file payload
		else
			exit
		fi
		echo ''
        	echo "New file list"
        	echo "========="
        	echo -e '\033[1;32m'
		cd payload
        	ls | cat -n
		echo -e '\033[1;39m'
        	echo -n "select your choice : "
        	read choice
        	if [[ $choice == "" ]]
        	then
                	exit
        	fi
        	out=`ls | sed -n $choice'p'`
        	touch index.php
        	echo "<?php" >> index.php
        	echo "header('location:$out');" >> index.php
        	echo "?>">> index.php
        	cd ..
        	echo -n "Enter port: "
        	read port
		if [[ $port == "" ]]
		then
			exit
		fi
		php -S localhost:$port -t `pwd`/payload
	else
		cd payload
		echo -n "select your choice : "
                read choice
		if [[ $choice == "" ]]
                then
                        exit
                fi
                out=`ls | sed -n $choice'p'`
                touch index.php
                echo "<?php" >> index.php
                echo "header('location:$out');" >> index.php
                echo "?>">> index.php
		cd ..
                echo -n "Enter port: "
                read port
		if [[ $port == "" ]]
		then
			exit
		fi
                php -S localhost:$port -t `pwd`/payload
	fi
else
	echo ''
	echo -n "Enter file path [example : /sdcard/p.apk] : "
	read file
	if [[ $file != "" ]]
	then
		cp -r $file payload
	else
		exit
	fi
	echo ''
	echo "file list"
	echo "========="
	echo -e '\033[1;32m'
	cd payload
	ls | cat -n
	echo -e "\033[1;39m"
	echo -n "select your choice : "
	read choice
	if [[ $choice == "" ]]
	then
        	exit
	fi
	out=`ls | sed -n $choice'p'`
	touch index.php
	echo "<?php" >> index.php
	echo "header('location:$out');" >> index.php
	echo "?>">> index.php
	cd ..
	echo -n "Enter port: "
	read port
	if [[ $port == "" ]]
	then
		exit
	fi
	php -S localhost:$port -t `pwd`/payload
fi
