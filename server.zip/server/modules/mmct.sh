cd /sdcard
python2 pyserver.py