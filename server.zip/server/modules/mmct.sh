cd $HOME
python2 pyserver.py