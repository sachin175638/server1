#python2

def twittercre():
 try:
  target = "files/twitter/file.txt"
  file = open(target, "r")
  text = file.read()
  file.close()
  print text
 except IOError:
  print ''
  print "No data found !"
  print ''

