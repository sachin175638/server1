#python2

def stackcre():
 try:
  target = "files/stackoverflow/file.txt"
  file = open(target, "r")
  text = file.read()
  file.close()
  print text
 except IOError:
  print ''
  print "No data found !"
  print ''

